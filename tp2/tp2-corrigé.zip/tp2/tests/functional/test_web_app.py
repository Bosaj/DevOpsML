import pytest
from test_git.web_app import create_app

@pytest.fixture()
def client():
    app = create_app({"TESTING": True})
    with app.test_client() as c:
        yield c

def test_health_ok(client):
    resp = client.get("/health")
    assert resp.status_code == 200
    assert resp.get_json() == {"status": "ok"}

@pytest.mark.parametrize("user_data", [
    ({"name": "Alice", "age": 30}),
    ({"name": "Bob", "age": 0}),
])
def test_create_user_success(client, user_data):
    resp = client.post("/users", json=user_data)
    assert resp.status_code == 201
    data = resp.get_json()
    assert data["name"] == user_data["name"]
    assert data["age"] == user_data["age"]
    assert "id" in data

def test_create_user_missing_name(client):
    resp = client.post("/users", json={"age": 30})
    assert resp.status_code == 400
    assert resp.get_json() == {"error": "name is required"}

def test_create_user_invalid_age(client):
    resp = client.post("/users", json={"name": "Alice", "age": -1})
    assert resp.status_code == 400
    assert resp.get_json() == {"error": "age must be a non-negative integer"}

def test_get_user_not_found(client):
    resp = client.get("/users/999999")
    assert resp.status_code == 404
    assert resp.get_json() == {"error": "not found"}

def test_update_user_success(client):
    # First create a user
    resp = client.post("/users", json={"name": "Charlie", "age": 25})
    user_id = resp.get_json()["id"]

    # Now update the user
    resp = client.put(f"/users/{user_id}", json={"name": "Charles", "age": 26})
    assert resp.status_code == 200
    data = resp.get_json()
    assert data["name"] == "Charles"
    assert data["age"] == 26
    assert data["id"] == user_id

def test_delete_user_success(client):
    # First create a user
    resp = client.post("/users", json={"name": "Dave", "age": 40})
    user_id = resp.get_json()["id"]

    # Now delete the user
    resp = client.delete(f"/users/{user_id}")
    assert resp.status_code == 204

    # Verify user is deleted
    resp = client.get(f"/users/{user_id}")
    assert resp.status_code == 404
    assert resp.get_json() == {"error": "not found"}