from test_git.exercice1 import multiplication, addition, subtraction, division
import pytest

@pytest.mark.parametrize("a,b,expected", [
    (1, 2, 3),
    (10000000000000000000000000000, 20000000000000000000000000000, 30000000000000000000000000000),
    (-1, 1, 0),
    (0, 0, 0),
])
def test_addition(a, b, expected):
    assert addition(a, b) == expected


@pytest.mark.parametrize("a,b,expected", [
    (5, 3, 2),
    (10000000000000000000000000000, 5000000000000000000000000000, 5000000000000000000000000000),
    (-1, -1, 0),
    (0, 0, 0),
])
def test_subtraction(a, b, expected):
    assert subtraction(a, b) == expected

@pytest.mark.parametrize("a,b,expected", [
    (4, 3, 12),
    (10000000000000000000000000000, 2, 20000000000000000000000000000),
    (-1, -1, 1),
    (0, 0, 0),
])
def test_multiplication(a, b, expected):
    assert multiplication(a, b) == expected

def test_division():
    assert division(10, 2) == 5

def test_division_zero():
    with pytest.raises(ValueError):
        division(10, 0)