import pytest
from test_git.exercice2 import supprimer_doublons_consecutifs

@pytest.mark.parametrize("input_list, expected_output", [
    ([], []),
    ([1, 1, 2, 2, 3, 3], [1, 2, 3]),
    (['a', 'a', 'b', 'b', 'c'], ['a', 'b', 'c']),
    ([1, 2, 3, 4], [1, 2, 3, 4]),
    (None, []),
])
def test_supprimer_doublons_consecutifs(input_list, expected_output):
    assert supprimer_doublons_consecutifs(input_list) == expected_output