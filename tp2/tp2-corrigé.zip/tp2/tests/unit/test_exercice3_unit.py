import pytest
from test_git.exercice3 import load_numbers, sum_numbers

@pytest.mark.parametrize("numbers", [
    ([1, 2, 3]),
    ([-1, -2, -3]),
    ([]),
])
def test_load_numbers(tmp_path, numbers):

    numbers_file = tmp_path / "numbers.txt"
    numbers_file.write_text("\n".join(str(num) for num in numbers) + "\n")

    loaded_numbers = load_numbers(numbers_file)
    assert loaded_numbers == numbers

@pytest.mark.parametrize("numbers, expected_sum", [
    ([1, 2, 3], 6),
    ([-1, -2, -3], -6),
    ([], 0),
])
def test_sum_numbers(numbers, expected_sum):
    assert sum_numbers(numbers) == expected_sum