import pytest
from test_git.exercice4 import load_users, filter_adults

@pytest.fixture
def users():
    return [
        {"name": "Ali", "age": 25},
        {"name": "Sara", "age": 17},
        {"name": "Mehdi", "age": 30},
    ]

def test_filter_adults(users):
    
    result = filter_adults(users)
    assert result == [
        {"name": "Ali", "age": 25},
        {"name": "Mehdi", "age": 30},
    ]

def test_load_users(tmp_path, users):
    csv_file = tmp_path / "users.csv"
    lines = ["name,age"] + [f"{u['name']},{u['age']}" for u in users]
    csv_file.write_text("\n".join(lines) + "\n", encoding="utf-8")

    loaded_users = load_users(csv_file)
    assert loaded_users == users

