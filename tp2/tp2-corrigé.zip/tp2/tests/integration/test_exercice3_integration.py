import pytest
from test_git.exercice3 import load_numbers, sum_numbers

@pytest.mark.parametrize("numbers, expected_sum", [
    ([1, 2, 3], 6),
    ([-1, -2, -3], -6),
    ([], 0),
])
def test_integration_load_and_sum(tmp_path, numbers, expected_sum):
    numbers_file = tmp_path / "numbers.txt"
    numbers_file.write_text("\n".join(str(num) for num in numbers) + "\n")

    loaded_numbers = load_numbers(numbers_file)
    total = sum_numbers(loaded_numbers)

    assert loaded_numbers == numbers
    assert total == sum(numbers)