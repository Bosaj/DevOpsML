
def supprimer_doublons_consecutifs(l):
    """Supprimer doublons consécutifs."""
    if not l:
        return []
    result = [l[0]]
    for elem in l[1:]:
        if elem != result[-1]:
            result.append(elem)
    return result