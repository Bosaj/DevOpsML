import csv 
def load_users(path): 
    with open(path, newline="", encoding="utf-8") as f: 
        reader = csv.DictReader(f) 
        return [{"name": r["name"], "age": int(r["age"])} for r in reader] 
    
def filter_adults(users): 
    return [u for u in users if u["age"] >= 18]

def load_users_with_id(path):
    """Reads CSV with schema: id,name,age -> [{'id': str, 'name': str, 'age': int}, ...]."""
    with open(path, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        out = []
        for r in reader:
            out.append({"id": str(r["id"]), "name": r["name"], "age": int(r["age"])})
        return out